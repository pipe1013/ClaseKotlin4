package com.pipe1013.fundamentoskotlin2.Apuntes

class Introduccion {
}

fun main() {
  var name:String="Felipe"
  var numLong:Long=3123213232332
  var numInt: Int=881213

  var numDouble: Double=3.12312
  var numFloat: Float= 4.23F
  var numChar: Char= '2'
  var boolean: Boolean= true

  /*println("La suma entre $num1 y $num2 es ${num1+num2}")
  print("$name.length is ${name.length}")*/

  /*print("Your name: ")
  var lastName = readLine()
  print("hello $lastName")*/

  /*print("Digite el numero 1: ")
  var num1: Int = readLine() !!.toInt()
  print("Digite el numero 2: ")
  var num2: Int = readLine() !!.toInt()
  print("La suma entre $num1 y $num2 es ${num1+num2}")*/

  var num3:Long?=null

}



