package com.pipe1013.fundamentoskotlin2.Apuntes

class Arrays {
}

fun main() {
    var pets= arrayOf("dog","cat","canary")
    println(pets.contentToString())

    pets[2]="parrot"


    //Imprimir un elmento en especifico del array
    print(pets[1])

    for ((index,element) in pets.withIndex()){
        println("La mascota No. $index es $pets")
    }



}