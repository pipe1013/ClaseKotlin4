package com.pipe1013.fundamentoskotlin2.Apuntes

import kotlin.math.sqrt

class Funciones {
}
fun perimetroTriangulo(side1: Int, side2: Int, side3: Int) {
    var perimetro = (side1 + side2 + side3)
    println("El perimetro de su circulo es: $perimetro")
}
fun areaTriangulo(base: Int, altura: Int) {
    var area = (base*altura)/2
    println("El Area de su triangulo es: $area")
}
fun perimetroRectangulo(side1: Int, side2: Int, side3: Int,side4: Int): Int {
    var perimetro = (side1 + side2 + side3 + side4)
    return perimetro
}

fun areaRectangulo(base: Int, altura: Int):Int {
    var area = base*altura
    return area
}


fun main() {
    var i = 1
    while (i == 1) {
        println("Por favor escoja una opción:\n (1) para triangulo \n (2) para circulo \n (3) para rectagulo ")
        var opcion: Int = readLine()!!.toInt()
        when (opcion) {
            1 -> {
                println("Por favor escoja una opción:\n (1) para perimetro \n (2) para area" )
                var opcio2: Int = readLine()!!.toInt()
               when(opcio2){

                   1->{
                       println("Por favor digite el lado 1 del triangulo")
                       var side1: Int = readLine()!!.toInt() ?: 0
                       println("Por favor digite el lado 2 del triangulo")
                       var side2: Int = readLine()!!.toInt() ?: 0
                       println("Por favor digite el lado 3 del triangulo")
                       var side3: Int = readLine()!!.toInt() ?: 0
                       perimetroTriangulo(side1,side2,side3)

                   }
                   2->{
                       println("Por favor digite la base del triangulo")
                       var base: Int = readLine()!!.toInt() ?: 0
                       println("Por favor digite la altura del triangulo")
                       var altura: Int = readLine()!!.toInt() ?: 0
                       areaTriangulo(base, altura )
                   }
               }


        }

            2-> {
                println("Por favor escoja una opción:\n (1) para perimetro \n (2) para area")
                var opcio2: Int = readLine()!!.toInt()
                when(opcio2){

                    1 -> {
                        fun perimetroCirculo() {

                            println("Bienvenido, vamos a calcular el perimetro de tu circulo!!")
                            println("Por favor digite el radio del su circulo")
                            var radio: Int =readLine()!!.toInt()
                            var perimetro = (2 * 3.1416) * radio
                            println("El perimetro de su circulo es: $perimetro")


                        }
                        perimetroCirculo()
                    }
                    2->{
                        fun areaCirculo() {
                            println("Bienvenido, vamos a calcular el area de tu circulo!!")
                            println("Por favor digite el radio del su circulo")
                            var radio: Int =readLine()!!.toInt()
                            var area = 3.1416 * (radio * radio)
                            println("El area de su circulo es: $area")


                        }
                        areaCirculo()
                    }
                }

            }
            3->{
                println("Por favor escoja una opción:\n (1) para perimetro \n (2) para area" )
                var opcio2: Int = readLine()!!.toInt()
                when(opcio2){

                    1->{
                        println("Por favor digite el lado 1 del rectangulo")
                        var side1: Int = readLine()!!.toInt() ?: 0
                        println("Por favor digite el lado 2 del rectangulo")
                        var side2: Int = readLine()!!.toInt() ?: 0
                        println("Por favor digite el lado 3 del rectangulo")
                        var side3: Int = readLine()!!.toInt() ?: 0
                        println("Por favor digite el lado 4 del rectangulo")
                        var side4: Int = readLine()!!.toInt() ?: 0
                        var peri= perimetroRectangulo(side1,side2,side3,side4)
                        println("El perimetro de su rectangulo es $peri")

                    }
                    2->{
                        println("Por favor digite la base del rectangulo")
                        var base: Int = readLine()!!.toInt() ?: 0
                        println("Por favor digite la altura del rectangulo")
                        var altura: Int = readLine()!!.toInt() ?: 0
                        var area= areaRectangulo(base,altura)
                        println("El area de su rectangulo es $area")
                    }
                }

            }

            }
        println("Desea digitar otra figura? :  \n (1) para si \n (2) para no")
        i = readLine()!!.toInt()
        }
    print("Gracias")

    }









